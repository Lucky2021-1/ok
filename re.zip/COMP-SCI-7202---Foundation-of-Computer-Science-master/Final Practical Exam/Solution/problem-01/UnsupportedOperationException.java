/*==================================
Foundations of Computer Science
Student: Vandit Jyotindra Gajjar
id: a1779153
Semester: 2
Year: 2019
Practical Exam Number: Final Practical Exam
===================================*/

import java.lang.*; 
import java.util.*;  

public class UnsupportedOperationException extends Exception{

	//Defining the exception - UnsupportedOperationException which accepts the String message for the given test case. 
    public UnsupportedOperationException(String s) {
        super(s);
    }

}