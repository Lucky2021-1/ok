/*==================================
Foundations of Computer Science
Student: Vandit Jyotindra Gajjar
id: a1779153
Semester: 2
Year: 2019
Practical Exam Number: Final Practical Exam
===================================*/

interface Structurable {

	//Defining sort and search method in interface class which throws exception for a given case. 
    int[] sort(int[] array) ;
    int search(String[] array, String value) ;
 
}
