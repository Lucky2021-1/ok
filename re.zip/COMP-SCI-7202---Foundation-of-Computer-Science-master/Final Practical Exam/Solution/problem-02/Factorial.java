/*==================================
Foundations of Computer Science
Student: Vandit Jyotindra Gajjar
id: a1779153
Semester: 2
Year: 2019
Practical Exam Number: Final Practical Exam
===================================*/

import java.lang.*; 
import java.util.*; 

public class Factorial {

    public int find(int x) throws UnsupportedOperationException {

        // Setting the coditions for throwing exceptions if value is negative. 
        if (x < 0) {
        
            throw new UnsupportedOperationException("Not defined.");
        
        } else {
    
        // Adding recursive solution here. 
            if (x >= 1) {
                return x * find(x - 1);
        
            } else {
        
                return 1;
            }

        }
    }

}