/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 name: Vandit Jyotindra Gajjar 
*
*/


import java.util.Random; 

public class RandomNumbers {

	public static void main(String[] args) { 

		
		//Creating variable and initiating random number.
		int sum = 0; 
		float mean; 
		Random random = new Random(); 

		//Defining loop with the conditions and printing the number. 
		for (int i = 1; i <= 10; i++) {

			int number = random.nextInt(10); 
			
			System.out.print(number + "\n"); 
			
			sum = sum + number; 
		}

		//Calculating the mean and converting into float value.
		mean = (float)(sum / 10.0); 
		
		System.out.println("Average of generated number : " + mean); 
	} 
} 

