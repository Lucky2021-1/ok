/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 name: Vandit Jyotindra Gajjar 
*
*/

import java.util.Random;

public class RandomNumbersWithStar {
	public static void main(String[] args) {

		//Creating variable and initiating random number.
		int sum = 0;
		float mean;
		Random random = new Random();
		System.out.print("\n");
		//Defining loop with the conditions and printing the stars corresponding to number. 
		for (int i = 1; i <= 10; i++) {

			
			int randomNumber = random.nextInt(20);
			System.out.print ("Number ( "+randomNumber+ ") : " );

			for (int j = 1; j <= randomNumber; j++) {

				System.out.print("*");
	
			}

			sum = sum + randomNumber;
			System.out.print("\n");
	
		}
	}
}
