//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// Student ID: a1779153
// Semester: 2
// Year: 2019
// Practical Number: 4 Part - II
//===================================


public class Test {
	public static void main(String[] args) {

		//Instatiating new object shakeTotal here. 
		ShakingParty shakeTotal = new ShakingPartyConstrainted(2);

		//Counting total hand shakes here using int variable count. 
		int count = shakeTotal.countHandShakes();
		System.out.println("total number of handshakes: " + count);
	}
}
