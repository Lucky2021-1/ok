//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// Student ID: a1779153
// Semester: 2
// Year: 2019
// Practical Number: 4 Part - II
//===================================

public class Test {
	public static void main(String[] args) {

		//Instatiating a new object shakeTotal here.
		ShakingParty shakeTotal = new ShakingParty(5);

		//Counting total number of hand shakes using integere variable count here.
		int count = shakeTotal.countHandShakes();
		System.out.println("total number of handshakes: " + count);
	}
}
