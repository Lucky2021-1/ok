/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

//Creating invalidexception class here. 
public class InvalidStringException extends Exception {

	//Developing Parametric constructor. 
    public InvalidStringException(String str) {
        super(str);
    }

}

