/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

//Logic - Human and Computer objects will be instatntiated, where Human enters an input, while based on random generation computer will generate its output. Based on the referees condition, decision will be made. 

import java.util.*;

public class Main {

	public static void main(String[] args) {

		//Instantiating input and referee for starting and evlauting match. 
		Scanner input = new Scanner(System.in);
		Referee object = new Referee();

		while (true){
			//Adding try - catch method for start the game and provide invalid input exception if occurs. 
			try {
        		object.startGame();

	       		}

	        	catch (InvalidStringException e) {
        			System.out.println();
        			System.out.println("String is not a valid Input");

        		}
    	
    		}

    	}

}
