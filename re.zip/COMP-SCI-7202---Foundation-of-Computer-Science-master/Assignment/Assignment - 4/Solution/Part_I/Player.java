/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

//Implementing interface for player. 
public interface Player {

	//Player move starts here and for wrong inputs throwing exception. 
	public String performMove() throws InvalidStringException;

}

