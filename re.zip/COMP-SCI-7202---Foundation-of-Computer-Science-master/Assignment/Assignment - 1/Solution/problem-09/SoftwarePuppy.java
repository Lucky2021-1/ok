/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 name: Vandit Jyotindra Gajjar 
*
*/

import java.util.*;

public class SoftwarePuppy {

	public static void main(String[] args) {

		Scanner input = new Scanner(System.in);
		Scanner inputOne = new Scanner(System.in);
		Scanner inputTwo = new Scanner(System.in);
		Scanner inputThree = new Scanner(System.in);

		// taking input from the user in string format and displaying information

		System.out.println("Please enter the name of puppy: ");
		String puppyName = input.nextLine();
		System.out.println();
		System.out.println("The name of puppy is " + puppyName);

		// taking input from the user in integer format and displaying information

		System.out.println();
		System.out.println("Please enter the age of puppy in years and monthss: ");
		int puppyAgeYear = input.nextInt();
		int puppyAgeMonth = input.nextInt();
		System.out.println();
		System.out.println("The age of puppy is " + puppyAgeYear + " years and " + puppyAgeMonth + " months.");

		// taking input from the user in String format and displaying information

		System.out.println();
		System.out.println("Please provide what food puppy likes ? ");
		String puppyFood = inputOne.nextLine();
		System.out.println();
		System.out.println("The " + puppyName + " likes " + puppyFood);

		// taking input from the user in integer format and displaying information

		System.out.println();
		System.out.println("Please enter the puppy's height in Foot and Inch ");
		int puppyHeightFoot = input.nextInt();
		int puppyHeightInch = input.nextInt();
		System.out.println();
		System.out.println("The " + puppyName + "'s height is " + puppyHeightFoot + " Foot and " + puppyHeightInch + " Inch.");		

		// taking input from the user in integer format and displaying information

		System.out.println();
		System.out.println("Please enter the puppy's Weight in Kg: ");
		float puppyWeight = input.nextFloat();
		System.out.println();
		System.out.println("The Weight of the puppy is " + puppyWeight + " Kg.");

		// taking input from the user in String format and displaying information

		System.out.println();
		System.out.println("Please enter the puppy's favorite toy: ");
		String puppyToy = inputTwo.nextLine();
		System.out.println();
		System.out.println("The " + puppyName + " likes " + puppyToy +".");

		// taking input from the user in String format and displaying information

		System.out.println();
		System.out.println("Please enter the puppy's owner name: ");
		String puppyOwner = inputThree.nextLine();
		System.out.println();
		System.out.println("The " + puppyName + "'s owner name is " + puppyOwner + ".");
		
	}

}
