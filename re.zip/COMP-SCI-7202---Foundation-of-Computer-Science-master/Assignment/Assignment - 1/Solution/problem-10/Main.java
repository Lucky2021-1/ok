/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 name: Vandit Jyotindra Gajjar 
*
*/

public class Main{
	public static void main(String [] args){

		// Creating and instantiating variable
		System.out.println();
		String agent_message_01282 = "Who are you?";
		System.out.println(agent_message_01282);
		
		// Creating and instantiating variable

		agent_message_01282 = "My name is, Bond...";
		System.out.println(agent_message_01282);

		// Creating and instantiating variable

		agent_message_01282 = "James Bond";
		System.out.println(agent_message_01282);

		// Creating and instantiating variable

		int agent_id = 007;
		agent_message_01282 = agent_message_01282 + "(00" + agent_id + ")";
		System.out.println(agent_message_01282);
		
		}

		
}
		
		

