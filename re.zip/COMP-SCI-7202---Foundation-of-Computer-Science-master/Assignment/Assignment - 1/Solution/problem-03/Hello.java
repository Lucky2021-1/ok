/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 name: Vandit Jyotindra Gajjar 
*
*/


public class Hello {

	public static void main(String[] args) {

			// Creating variable 

		String input = "Hello world";

			// Display information 
		
		System.out.println(input);
	
	}
	
}
