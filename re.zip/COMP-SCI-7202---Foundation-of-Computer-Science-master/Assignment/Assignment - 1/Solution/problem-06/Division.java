/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 name: Vandit Jyotindra Gajjar 
*
*/

import java.util.*;

public class Division {
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);

		// creating variable
		
		float C;

		// taking input from the user for int A and B
		
		System.out.println("Enter integer A: ");
		int A = input.nextInt();
		System.out.println("Enter integer B: ");
		int B = input.nextInt();

		// Conditional block for division of variables A and B
		if (B == 0) {
			
			System.out.println("Division by zero is not defined!");
			C = 0;
		
		} else {
			
			C = (float) A / B;
		
		}

		// Display information for the user
		System.out.println();
		System.out.printf("The division of %d by %d is %f\n", A, B, C);
	}
	
}
