//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// Student ID: a1779153
// Semester: 2
// Year: 2019
// Practical Number: 5 Part - II
//===================================

// Base class - MySearchAlg which is abstract class.

public abstract class MySearchAlg {
	abstract int search (int[] array, int num);
}
