//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// Student ID: a1779153
// Semester: 2
// Year: 2019
// Practical Number: 5 Part - I
//===================================

// Base class - MySortAlg which is an abstract class.

public abstract class MySortAlg {
	public abstract int[] sort(int[] array);

	// Method to print given array. 	
	public void printArray(int[] array) {

		System.out.print("[");
		
		for (int i = 0; i < array.length; i++) {
			if (i == array.length - 1) {
				System.out.println(array[i] +" ]");
			}
			else {
				System.out.print(array[i] + ", ");
			}
		}
	}
}
