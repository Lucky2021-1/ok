/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

public class Lion extends Animal {

	//Default constructor
	Lion() {
		
		//Calling the base constructor.
		super();
	}

	//Parametric Constructor
	Lion(String name, double weight, String favouriteFood, int age) {
		
		//Calling the base constructor.
		super(name, weight, favouriteFood, age); 
	}

	//Defining abstract method makeSound.
	@Override
	public void makeSound() {
		System.out.println("Make sound: ");
	}	
}
