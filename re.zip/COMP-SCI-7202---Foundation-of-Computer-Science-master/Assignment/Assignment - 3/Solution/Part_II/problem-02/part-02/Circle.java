/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

public class Circle extends Shape {

	//Default constructor
	Circle() {

		//Calling the base constructor.
		super();
	}

	//Parametric Constructor
	Circle(double radius) {

		//Calling the base constructor.
		super(0, 0, radius, 0); 
	}

	//Defining abstract method.
	@Override
	public double area() {
		return Math.PI * this.getRadius();
	}
}
