/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

public class Hibrid extends Bicycle {

	//List of private attributes.
	private String suspension;

	//Defualt constructor.
	Hibrid() {
		super("Green", 2017, 18, false, "10/10/2019", "12/11/2020", "not serviced");
		this.suspension = "none";
	}

	//Parametric constructor.
	Hibrid(String color, int year, int numberGears, boolean is_serviced, String inDate, String outDate, String serviceResponsible, String suspension) {
		super(color, year, numberGears, is_serviced, inDate, outDate, serviceResponsible);
		this.suspension = suspension;
	}

	//Creating accessor getSuspension.
	public String getSuspension() {
		return this.suspension;
	}

	//Creating mutators getSuspension.
	public void setSuspension(String suspension) {
		this.suspension = suspension;
	}
}
