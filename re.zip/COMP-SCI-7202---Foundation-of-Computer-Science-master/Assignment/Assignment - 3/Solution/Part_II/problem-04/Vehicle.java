/*
*
* Foundations of Computer Science
* Semester 02 Year 2019
* id: a1779153 
* name: Vandit Jyotindra Gajjar 
*
*/

interface Vehicle {
	void changeGear(int a);
	void checkBrakes();
}
