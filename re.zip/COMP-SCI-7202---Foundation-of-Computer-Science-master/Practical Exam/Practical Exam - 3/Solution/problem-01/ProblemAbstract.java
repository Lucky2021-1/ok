//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 3
//===================================

//Defining abstarct class here. 

public abstract class ProblemAbstract { 
	//Defining method here accepts a string.
	public abstract void solve(String word);
}