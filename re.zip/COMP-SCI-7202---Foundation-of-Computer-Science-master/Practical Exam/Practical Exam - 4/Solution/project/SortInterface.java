/*
*   Foundations of Computer Science
*   2019, Semester 02
*   Practical-Exam-04
*
*   student (id): a1779153
*   student (name): Vandit Jyotindra Gajjar
*
*
* Note: in order to finish your exam you are NOT required to make any changes in this class
*
*/
public interface SortInterface{

	public int [] sortIntByIndex(int [] arr);
	public int [] sortStringByIndex(String [] arr);

}
