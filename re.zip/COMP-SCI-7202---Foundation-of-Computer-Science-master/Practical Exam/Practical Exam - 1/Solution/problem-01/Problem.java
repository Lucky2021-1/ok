//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 1
//===================================

public class Problem {
	public static void main(String[] args) {
			System.out.println("Hello World!");
		}	
}