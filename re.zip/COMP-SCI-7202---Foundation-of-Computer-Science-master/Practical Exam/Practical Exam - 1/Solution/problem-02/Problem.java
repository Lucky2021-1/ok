//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 1
//===================================

public class Problem {
	public static void main(String[] args) {
			int i;
			System.out.print("[" );
			for (i = 101; i >= 89 ; --i ) {
				
				System.out.print(i + ", ");
								
			}
			System.out.print("]");
		}	
}