//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 1
//===================================

import java.util.*;

public class Problem {
	public static void main(String[] args) {
		
		int i, j;
		char printChar;

		for ( i = 1; i <= 40 ; i++ ) {
			
			switch (i) {
					case 1:
					case 2:
					case 3:
					case 4:
					case 5:
					case 6:
					case 7:
					case 8:
					case 9:
					printChar = '*';	
					break;



					case 10:
					case 11:
					case 12:
					case 13:
					case 14:
					case 15:
					case 16:
					case 17:
					case 18:
					case 19:
					printChar = '=';
					break;

					case 20:
					case 21:
					case 22:
					case 23:
					case 24:
					case 25:
					case 26:
					case 27:
					case 28:
					case 29:
				
					printChar = 'x';
					break;

					default:
					printChar = 'o';
				}

		for (j = 1; j <= i ; j++) {
			
			System.out.print(printChar);

		}

		System.out.print("\n");
			
		}

	}
	
}