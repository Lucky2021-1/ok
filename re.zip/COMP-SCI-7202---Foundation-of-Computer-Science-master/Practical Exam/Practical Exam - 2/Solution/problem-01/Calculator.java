//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 2
//===================================

public class Calculator {

	// Craeting a method name Sum.
	public int sum(int numA, int numB){
		int sum = 0;
		sum = numA + numB;
		return sum;
	}

	// Craeting a method name Sub.
	public int sub(int numA, int numB){
		int sub = 0;
		sub = numA - numB;
		return sub;
	}
	
	// Craeting a method name Mul.
	public float multiply(float numA, float numB){
		float mul = 0;
		mul = numA * numB;
		return mul;
	}

	// Craeting a method name Div.
	public float division(float numA, float numB){
		float div = 0;
		
		//Main Logic here if divided by zero.
		if (numB == 0){
			div = -99.0f;
		}

		else {
			div = numA/numB;
		}
		return div;
	}
	
}