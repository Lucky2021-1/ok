//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 2
//===================================

import java.util.*;

public class HandlingArrays {

	//Printing the array using java's available utility.
	public static void printArray(double [] testArray){
		System.out.println(Arrays.toString(testArray));
	}

/*	public static double[] sumElements(double [] firstArray, double [] secondArray){


	}*/

	
	//Printing the reverse array using taking a temp type. 
	public static double[] reverseArray(double [] testArray){
  			
  			// Main Logic here.
    		for (int counter = 0; counter < testArray.length / 2; counter++) {
      			double temp = testArray[counter];
      			testArray[counter] = testArray[testArray.length - 1 - counter];
     	 		testArray[testArray.length - 1 - counter] = temp;
   			}
  	return testArray;
 	}

}
		