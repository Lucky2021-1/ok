//==================================
// Foundations of Computer Science
// Student: Vandit Jyotindra Gajjar
// id: a1779153
// Semester: 2
// Year: 2019
// Practical Exam Number: 2
//===================================

public class Character {
	
	private String name;
	private int age;
	private String gender;
	private String occupation;
	private String familyRole;
	private float rate;


	// Creating the accessors for name, age, gender, occupation, familyRole, and rate.
	public String getName(){
		return name;
	}

	public int getAge(){
		return age;
	}

	public String getGender(){
		return gender;
	}

	public String getOccupation(){
		return occupation;
	}

	public String getFamilyRole(){
		return familyRole;
	}

	public float getRate(){
		return rate;
	}


	// Creating the mutators for name, age, gender, occupation, familyRole, and rate.
	public void setName(String newName){
		name = newName;
	}

	public void setAge(int newAge){
		age = newAge;
	}

	public void setGender(String newGender){
		gender = newGender;
	}

	public void setOccupation(String newOccupation){
		occupation = newOccupation;
	}

	public void setFamilyRole(String newFamilyRole){
		familyRole = newFamilyRole;
	}

	public void setRate(float newRate){
		rate = newRate;
	}

	//default constructor
	Character(){

	}

	//parametric constructor
	Character(String name, int age, String gender, String occupation, String familyRole, float rate){
		name = newName;
		age = newAge;
		gender = newGender;
		occupation = newOccupation;
		familyRole = newFamilyRole;
		rate = newRate;		


	}



}