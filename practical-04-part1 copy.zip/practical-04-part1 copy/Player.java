
//Implementing interface for player. 
public interface Player {

	//Player move starts here and for wrong inputs throwing exception. 
	public String performMove() throws InvalidStringException;

}

