
import java.util.*;

public class Main {

	public static void main(String[] args) {

		//Instantiating input and referee for starting and evlauting match. 
		Scanner input = new Scanner(System.in);
		Referee ref = new Referee();

		while (true){
			//Adding try - catch method for start the game and provide invalid input exception if occurs. 
			try {
        		ref.goGame();

	       		}

	        	catch (InvalidStringException e) {
        			System.out.println();
        			System.out.println("String is not a valid Input");

        		}
    	
    		}

    	}

}
