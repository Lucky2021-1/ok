
public class InvalidStringException extends Exception {

	//Developing Parametric constructor. 
    public InvalidStringException(String message) {
        super(message);
    }

}

