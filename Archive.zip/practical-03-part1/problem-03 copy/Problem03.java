

import java.util.*;

public class Problem03 {

  static void compareNumber() {

    
    try {  
  
      int i, j, big;
      Scanner scan = new Scanner(System.in);

      //Asking for user input here.
      System.out.print("----------");
      System.out.println();
      System.out.print("Please, insert a number (1) : ");
      i = scan.nextInt();
      System.out.print("Please, insert a number (2) : ");
      j = scan.nextInt();
      //Creating logic here.
      if(i>j) {
        big = i;
      }
      
      else {
        big = j;
      }
        
      System.out.print("The bigger number is " +big);
      System.out.println();
      System.out.print("----------");
    }

    catch (Exception e) {
      System.out.println();
      System.out.println("Please do not use any other variable type!");
   } 

    finally{
      System.out.println();
      System.out.println("The try catch is finished, you must use Integer in both inputs. ");
  }
}
  
  public static void main(String[] args) {
    compareNumber();
  }  
}   
