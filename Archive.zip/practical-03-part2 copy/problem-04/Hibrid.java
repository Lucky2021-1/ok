

public class Hibrid extends Bicycle {

	
	private String suspension;

	//Defualt constructor.
	Hibrid() {
		super("Green", 2017, 16, false, "10/10/2019", "12/11/2020", "not serviced");
		this.suspension = "none";
	}

	//Parametric constructor.
	Hibrid(String color, int year, int numberGears, boolean is_serviced, String inDate, String outDate, String serviceResponsible, String suspension) {
		super(color, year, numberGears, is_serviced, inDate, outDate, serviceResponsible);
		this.suspension = suspension;
	}

	//Creating accessor getSuspension.
	public String getSuspension() {
		return this.suspension;
	}

	//Creating mutators getSuspension.
	public void setSuspension(String suspension) {
		this.suspension = suspension;
	}
}
