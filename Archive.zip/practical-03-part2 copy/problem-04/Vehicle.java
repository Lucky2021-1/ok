

interface Vehicle {
	void changeGear(int a);
	void checkBrakes();
}
