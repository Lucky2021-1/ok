

public class EBook extends Book {
	
	//List of private attributes.
	private String url;

	//Default constructor
	EBook() {

		//Calling the base constructor.
		super();
		this.url = "hhh";
	}

	//Parametric Constructor
	EBook(String title, int year, String publish, int pages,String url) {
		
		//Calling the base constructor.
		super(title, year, publish, pages);
		this.url = url;
	}

	//Creating accessors for URL. 
	public String getUrl() {
		return this.url;
	}

	//Creating mutators for URL. 
	public void setUrl(String url) {
		this.url = url;
	}
}
