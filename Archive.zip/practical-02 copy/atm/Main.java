import java.util.Scanner;

public class Main {
	public static void main(String[] args) {
		//ask user input a number
		System.out.println("Please enter a number: ");
		Scanner sc = new Scanner(System.in);
		int money = sc.nextInt();

		//call method
	}

	public static String run(int money) {
		int a = 0;
		int b = 0;

		a = money / 50; //a is the amount of $50 notes

		int left = money -(a*50);

		if(left%20 == 0){
			b = left /20; //b is the amount of $20 notes

			//note amount should not be less than 0
			if(a >= 0 && b >= 0 && ((50 * a) + (20 *b)) == money){
				return "Here is " + b + "$20 notes and " + a + "$50 notes.";

			} else {
				return "Sorry, the value you input cannot be withdrew.";

			}
		} else {
			a = a -1;
			left = money - (a*50);
			b = left/20;
			if(a >= 0 && b >= 0 && ((50 * a) + (20 *b)) == money){
				return "Here is " + b + "$20 notes and " + a + "$50 notes.";

			} else {
				return "Sorry, the value you input cannot be withdrew.";

			}
		}
	}
}