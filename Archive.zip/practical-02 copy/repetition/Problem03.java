import java.util.*;
import java.lang.Math;

public class Problem03{
	public static void main(String[] args) {
		Random ran = new Random();

		int avg = 0;
		int sum = 0;

		for(int i = 0; i < 10; i++) {
			int num = ran.nextInt(20);
			System.out.print("Number (" + num + "): ");

			sum += num;
			avg = Math.round(sum / 10);

			for(int j = 0; j < num; j++) {
				if(num % 2 ==0) {
					System.out.print('+');
				} else {
					System.out.print('-');
				}
			}
			System.out.println();
		}
		System.out.print("Average (" + avg + "): ");
		for(int k =0; k < avg; k++) {
			System.out.print('*');
		}
	}
}