import java.util.*;
import java.lang.Math;

public class Problem02 {
	public static void main(String[] args) {
		Random r = new Random();

		int avg = 0;
		int sum = 0;

		for(int i =0; i< 10; i++) {
			//create and print random 10 number 0-20
			int number = r.nextInt(20) +1;
			System.out.print("Number (" + number +"): ");

			//calculate the sum the rounded average of numbers
			sum += number;
			

			//print stars
			for(int j=0; j < number; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
		avg = Math.round(sum/10);
		System.out.print("Average (" + avg + "): ");

		//print stars
		for(int k = 0; k < avg; k++) {
			System.out.print('*');
		}
		System.out.println();
	}

}