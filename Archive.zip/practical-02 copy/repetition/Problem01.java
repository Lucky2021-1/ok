import java.util.*;
import java.lang.Math;

public class Problem01 {
	public static void main(String[] args) {
		Random ran = new Random();
		
		for(int i=0; i < 10; i++) {
			int num = ran.nextInt(20);
			System.out.print("Number (" + num + "): ");


			for(int j = 0; i < num; j++) {
				System.out.print('*');
			}
			System.out.println();
		}
	}
}