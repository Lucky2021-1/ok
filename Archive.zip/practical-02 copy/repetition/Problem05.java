import java.util.*;
public class Problem05 {
    public static void main(String[] arges) {
        Random r = new Random();

        for (int i = 0; i < 10; i++) {
            // create and print random 10 numbers between 0-20
            int number = r.nextInt(20);
            System.out.print("Number (" + number + "): ");

            
            switch (number) {
                //o, for numbers between [0,5];
                case 0, 1, 2, 3, 4, 5:
                    System.out.println('o');
                    break;

                //x, for numbers between (5, 10];
                case 6, 7, 8, 9, 10:
                    System.out.println('x');
                    break;

                //s, for numbers between (10, 15];
                case 11, 12, 13, 14, 15:
                    System.out.println('s');
                    break;

                //*, for numbers bigger than 15;
                default:
                    System.out.println('*');
                    break;
            }
        }
    }
}