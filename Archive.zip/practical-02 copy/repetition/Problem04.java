import java.util.*;
import java.lang.Math;

public class Problem04 {
    public static void main(String [] arges) {
        Random ra = new Random();

        int average = 0;
        int sum = 0;

        for (int i = 0; i < 10; i++) {
            
            int num = ra.nextInt(20);
            System.out.print("Number (" + num + "): ");

            // calculate the sum and rounded average of numbers
            sum += num;
            average = Math.round(sum / 10);

            
            for (int j = 0; j < num; j++) {
                if (num >= 10) {
                    System.out.print(">=");
                } else {
                    System.out.print("<");
                }
            }
            System.out.println();
        }
        System.out.print("Average (" + average + "): ");
        //print stars
        for (int k = 0; k < average; k++) {
            System.out.print('*');
        }
    }
}