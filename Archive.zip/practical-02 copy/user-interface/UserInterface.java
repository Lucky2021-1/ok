import java.util.Scanner;

public class UserInterface {
    public static void main(String[] arges) {
        System.out.println("Welcome dear user!");


        
        while (true) {
            System.out.println("Would you like to:");
            System.out.println("a) sum again");
            System.out.println("b) exit)");
            System.out.print("Option: ");

            //ask user to input option a or b
            Scanner in = new Scanner(System.in);
            String input = in.nextLine();

            if (in.equals("a")) {
                Scanner numberInput = new Scanner(System.in);
                System.out.print("Please, insert the first number: ");
                int firstNumber = numberInput.nextInt();
                System.out.print("Please, insert the second number: ");
                int secondNumber = numberInput.nextInt();

                int sum = 0;
                sum = firstNumber + secondNumber;
                System.out.println("----");
                System.out.println("Thank you for your enquiry, the sum between " + firstNumber + " and " + secondNumber + " is " + sum + " . \n");

               
            } else if (in.equals("b")) {
                System.out.println("Thank you! Have a good day.");
                break;
            }
            //if user enter something else, loop will repeat
            else {
                System.out.println("Please select again");
            }
        }
    }
}