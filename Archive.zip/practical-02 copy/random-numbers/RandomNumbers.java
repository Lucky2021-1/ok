import java.util.*;

public class RandomNumbers {
    public static void main(String[] args) {
        Random r = new Random();
        int sum = 0;
        int[] arr = new int[10];

        System.out.print("[");
        int i;
        for(i = 0; i < arr.length; i++) {
            arr[i] = r.nextInt(10);

            if(i == arr.length -1) {
                System.out.print(arr[i]);
            } else {
                System.out.print(arr[i] + ",");
            }

            sum = sum + arr[i];
        }
        
        System.out.print("]");

        //print out the sum of numbers
        float mean = (float) sum /10;
        System.out.println("\nThe sum is: " + sum);
        System.out.println("The mean is: " + mean);
    }
}
